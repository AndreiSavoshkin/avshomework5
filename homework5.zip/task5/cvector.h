#ifndef CVECTOR_H_
#define CVECTOR_H_

#include <string.h>
#include <stdlib.h>  // для некоторых функций для работы с памятью
 
//Стандартный размер вектора при инициализации
#define CVECTOR_INIT_CAPACITY 4
 
/*
* Структура, представляющая собой "объект" вектора.
*
*/
typedef struct{
void** data;
int size;
int capacity;
size_t element_size;
} cvector;
 
/*
* Инициализация структуры вектора.
*/
void cvector_init(cvector* vector, size_t dataSize);
 
/*
* Функция, которая возвращает текущее количество.
* элементов в векторе
*/
int cvector_size(cvector* vector);
 
/*
* Функция добавления данных в конец вектора.
*/
void cvector_push(cvector* vector, void* data);
 
 
/*
* Удаление элемента из вектора по индексу.
*/
int cvector_delete(cvector* vector, int index);
 
/*
* Получение значения элемента по индексу.
*/
void* cvector_get(cvector* vector, int index);
 
/*
* Полная очистка вектора.
*/
void cvector_clear(cvector* vector);
 
void cvector_resize(cvector* vector, int newCapacity);
 
#endif /* CVECTOR_H_ */