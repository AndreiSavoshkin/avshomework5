#ifndef __property__
#define __property__

//------------------------------------------------------------------------------
// property.h - содержит описание имущества и его интерфейса
//------------------------------------------------------------------------------

#include "rnd.h"
#include "stdio.h"

// автобус
class Property {
private:
    static Random rnd1000;
public:
    int id; // товарный номер имущества
    int cost; //стоимость
    virtual ~Property() {}
    // Случайная генерация товара
    static Property* InRnd();
};

#endif //__property__
