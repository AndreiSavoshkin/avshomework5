#include "cvector.h"
#include "property.h"
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

typedef struct {
    int market_percent;
    cvector v;
    cvector truck;
    // Для нахождения товара на складе
    sem_t make_property;
    // Для доставки товара со склада промежуточному звену
    sem_t get_property;
    // Для доставки товара с промежточного звена в грузовик
    sem_t get_in_truck;
    // Для рассчета рыночной стоимости
    sem_t get_price;
    //Для оповещения, что нахождение на складе успешно завершено
    bool searching_finished;
    // Для оповещения, что имущество перенесено в грузовик
    bool transportation_finished;
} Properties;

// Аргументы для передачи в аргументы функции потока
typedef struct {
    Properties* pr;
    int size;
} arg_struct;

static void* getPropertiesFromWarehouse(void* arguments)
{
    arg_struct* args = (arg_struct*)arguments;
    Properties* properties = args->pr;
    int items = args->size;
    for (int i = 0; i < items; i++) {
        printf("\e[1;33m1-ый поток (Иванов)\n\e[0m");

        sem_wait(&properties->make_property);
        printf("Searching %d property...\n", i + 1);
        //Забираем новый элемент
        printf("Got property\n");
        cvector_push(&properties->v, Property::InRnd());
        sem_post(&properties->get_property);
        sleep(2);
    }
    //Работа завершена
    properties->searching_finished = true;
    sleep(4);
    return nullptr;
}

static void* getPropertiesToTruck(void* arguments) {
    arg_struct* args = (arg_struct*)arguments;
    Properties* properties = args->pr;
    int counter = 0;
    // Пока нахождение имущества не завершено
    while (!properties->searching_finished) {
        sleep(2);
        printf("\e[1;33m2-ой поток (Петров)\n\e[0m");
        sem_wait(&properties->get_property);
        //Если хранилище не пусто
        while (cvector_size(&properties->v) != 0) {
            printf("\e[1;34mGot property #%d from warehouse:\n\e[0m", ++counter); //Выводим на экран последний добавленный элемент
            printf("\e[1;36mId = %d\n\e[0m", ((Property*)cvector_get(&properties->v, 0))->id);
            sem_wait(&properties->get_in_truck);
            cvector_push(&properties->truck, (Property*)cvector_get(&properties->v, 0)); // добавляем в грузовик
            cvector_delete(&properties->v, 0); //Удаляем его
            sem_post(&properties->get_price);
            sleep(2);
        }
        if (properties->searching_finished) {
            properties->transportation_finished = true;
            return nullptr;
        }
        sem_post(&properties->make_property);
    }
    return nullptr;
}

static void* getPropertiesMarketPrice(void* arguments) {
    arg_struct* args = (arg_struct*)arguments;
    Properties* properties = args->pr;
    int counter = 0;
    // Пока перенос не завершен
    while (!properties->transportation_finished) {
        sleep(4);
        printf("\e[1;33m3-ий поток (Нечепорчук)\n\e[0m");
        sem_wait(&properties->get_price);
        //Если грузовик не пуст
        while (cvector_size(&properties->truck) != 0) {
            printf("\e[1;35mGot property #%d to truck:\n\e[0m", ++counter); //Выводим на экран последний элемент
            printf("\e[1;36mId = %d\n", ((Property*)cvector_get(&properties->truck, cvector_size(&properties->truck) - 1))->id); //Выводим на экран последний элемент
            float price = ((Property*)cvector_get(&properties->truck, cvector_size(&properties->truck) - 1))->cost * (1 + (double)properties->market_percent / 100);
            printf("Market price = %.2f\n\e[0m", price);
            cvector_delete(&properties->truck, cvector_size(&properties->truck) - 1); //Удаляем его
        }
        if (properties->searching_finished) {
            return nullptr;
        }
        sem_post(&properties->get_in_truck);
    }
    return nullptr;
}

int main() {
    int size;
    printf("Введите количество имущества на складе от 1 до 1000: ");
    if ( (scanf("%d",&size) ) != 1 || size < 1 || size > 1000){
        printf("Неверное введенное значение");
        return 1;
    }
    int market_percent; // наценка
    printf("Введите значение рыночной наценки от 0 до 100% : ");
    if ( (scanf("%d",&market_percent) ) != 1 || market_percent < 0 || market_percent > 100){
        printf("Неверное введенное значение");
        return 1;
    }
    
    cvector v;
    cvector_init(&v, sizeof(Property));
    cvector truck;
    cvector_init(&truck, sizeof(Property));
    sem_t make_property;
    sem_t get_property;
    sem_t get_in_truck;
    sem_t get_price;
    sem_init(&make_property, 0, 1);
    sem_init(&get_property, 0, 0);
    sem_init(&get_in_truck, 0, 1);
    sem_init(&get_price, 0, 0);
    bool searching_finished { false };
    bool transportation_finished { false };
    Properties properties { market_percent, v, truck, make_property, get_property, get_in_truck, get_price,
        searching_finished, transportation_finished };

    arg_struct args;
    args.pr = &properties;
    args.size = size;
    pthread_t thread[3];
    pthread_create(&thread[0], NULL, getPropertiesFromWarehouse, &args);
    pthread_create(&thread[1], NULL, getPropertiesToTruck, &args);
    pthread_create(&thread[2], NULL, getPropertiesMarketPrice, &args);
    //pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);
    pthread_join(thread[2],NULL);
    return 0;
}