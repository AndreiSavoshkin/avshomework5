#include "cvector.h"
 
void cvector_init(cvector* vector, size_t dataSize) {
	vector->capacity = CVECTOR_INIT_CAPACITY;
	vector->size = 0;
	vector->element_size = dataSize;
	vector->data = (void **) malloc(CVECTOR_INIT_CAPACITY * sizeof(void*));
}
 
int cvector_size(cvector* vector){
	return vector->size;
}
 
void cvector_push(cvector* vector, void* data) {
	if(vector->size >= vector->capacity)
			cvector_resize(vector, vector->capacity + vector->capacity / 2);
 
	vector->data[vector->size] = (void*) malloc(vector->element_size);
	memcpy(vector->data[vector->size], data, vector->element_size);
 
	vector->size++;
}
 
int cvector_delete(cvector* vector, int index) {
	if(index < 0 || index > vector->size - 1 || vector->size <= 0)
		return 0;
 
	free(cvector_get(vector, index));
 
	for(int i = index; i < vector->size - 1; i++)
		vector->data[i] = vector->data[i + 1];
	 
	cvector_resize(vector, vector->size - 1);
	vector->size--;
	return 1;
}
 
void* cvector_get(cvector* vector, int index){
	if(index < 0 || index > vector->size - 1 || vector->size <= 0)
		return NULL;
 
	return vector->data[index];
}
 
void cvector_clear(cvector* vector){
	for(int i = 0; i < vector->size; i++)
	    free(vector->data[i]);
	vector->size = 0;
	free(vector->data);
}
 
void cvector_resize(cvector* vector, int newCapcity){
	vector->capacity = newCapcity;
	vector->data = (void**)realloc(vector->data, newCapcity * sizeof(void*));
}